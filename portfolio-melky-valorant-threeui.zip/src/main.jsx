import React from "react";
import { createRoot } from "react-dom/client";
import { DefenseLines } from "@designcodeio/threeui/components/DefenseLines";
import { InterfaceLines } from "@designcodeio/threeui/components/InterfaceLines";
import "@designcodeio/threeui/style.css";
import "../styles-valorant.css";

function mountWhenVisible(id, effect) {
  const host = document.getElementById(id);
  if (!host) return;
  const observer = new IntersectionObserver(([entry]) => {
    if (!entry.isIntersecting) return;
    createRoot(host).render(effect);
    observer.disconnect();
  }, { rootMargin: "140px" });
  observer.observe(host);
}

mountWhenVisible("threeui-hero-lines", <DefenseLines mode="light" speed={0.22} size={0.65} length={0.82} density={0.42} opacity={0.48} hue={0} className="threeui-canvas" />);
mountWhenVisible("threeui-work-lines", <InterfaceLines mode="light" speed={0.18} size={0.7} length={0.8} density={0.48} opacity={0.22} className="threeui-canvas" />);
